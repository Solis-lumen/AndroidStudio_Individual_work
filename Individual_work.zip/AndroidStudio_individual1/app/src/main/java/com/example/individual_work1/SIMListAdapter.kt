//package com.example.individual_work1
//
//import android.content.Intent
//import android.graphics.Color
//import android.net.Uri
//import android.os.Bundle
//import androidx.activity.enableEdgeToEdge
//import androidx.appcompat.app.AppCompatActivity
//import androidx.core.view.ViewCompat
//import androidx.core.view.WindowInsetsCompat
//
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.TextView
//import android.widget.Toast
//import androidx.recyclerview.widget.DiffUtil
//import androidx.recyclerview.widget.ListAdapter
//import androidx.recyclerview.widget.RecyclerView
//
////class SIMListAdapter :
////    ListAdapter<SIMData, SIMListAdapter.SIMViewHolder>(DiffCallback) {
////
////    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SIMViewHolder {
////        val view = LayoutInflater.from(parent.context)
////            .inflate(R.layout.item_sim_card, parent, false)
////        return SIMViewHolder(view)
////    }
////
////    override fun onBindViewHolder(holder: SIMViewHolder, position: Int) {
////        val item = getItem(position)
////        holder.bind(item)
////    }
////
////    class SIMViewHolder(view: View) : RecyclerView.ViewHolder(view) {
////        private val carrierName: TextView = view.findViewById(R.id.carrierNameTextView)
////        private val slotIndex: TextView = view.findViewById(R.id.slotIndexTextView)
////
////        fun bind(simData: SIMData) {
////            carrierName.text = "Carrier: ${simData.carrierName}"
////            slotIndex.text = "Slot: ${simData.slotIndex}, MCC: ${simData.mcc}, MNC: ${simData.mnc}"
////        }
////    }
////
////    companion object DiffCallback : DiffUtil.ItemCallback<SIMData>() {
////        override fun areItemsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
////            return oldItem.slotIndex == newItem.slotIndex
////        }
////
////        override fun areContentsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
////            return oldItem == newItem
////        }
////    }
////}
//
//
//
//
////class SIMListAdapter(private val listener: OnSIMClickListener) :
////    ListAdapter<SIMData, SIMListAdapter.SIMViewHolder>(DiffCallback) {
////
////    private var selectedPosition = RecyclerView.NO_POSITION
////
////    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SIMViewHolder {
////        val view = LayoutInflater.from(parent.context)
////            .inflate(R.layout.item_sim_card, parent, false)
////        return SIMViewHolder(view)
////    }
////
////    override fun onBindViewHolder(holder: SIMViewHolder, position: Int) {
////        val item = getItem(position)
////        holder.bind(item, position == selectedPosition)
////        holder.itemView.setOnClickListener {
////            val previousPosition = selectedPosition
////            selectedPosition = holder.adapterPosition
////            notifyItemChanged(previousPosition)
////            notifyItemChanged(selectedPosition)
////            listener.onSIMClick(item)
////        }
////    }
////
////    class SIMViewHolder(view: View) : RecyclerView.ViewHolder(view) {
////        private val carrierName: TextView = view.findViewById(R.id.carrierNameTextView)
////        private val slotIndex: TextView = view.findViewById(R.id.slotIndexTextView)
////
////        fun bind(simData: SIMData, isSelected: Boolean) {
////            carrierName.text = "Carrier: ${simData.carrierName}"
////            slotIndex.text = "Slot: ${simData.slotIndex}, MCC: ${simData.mcc}, MNC: ${simData.mnc}"
////            itemView.setBackgroundColor(
////                if (isSelected) Color.LTGRAY else Color.WHITE
////            )
////        }
////    }
////
////    interface OnSIMClickListener {
////        fun onSIMClick(simData: SIMData)
////    }
////
////    companion object DiffCallback : DiffUtil.ItemCallback<SIMData>() {
////        override fun areItemsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
////            return oldItem.slotIndex == newItem.slotIndex
////        }
////
////        override fun areContentsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
////            return oldItem == newItem
////        }
////    }
////}
//
//
//
////class SIMListAdapter(private val listener: OnSIMClickListener) :
////    ListAdapter<SIMData, SIMListAdapter.SIMViewHolder>(DiffCallback) {
////
////    private var selectedPosition = RecyclerView.NO_POSITION
////
////    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SIMViewHolder {
////        val view = LayoutInflater.from(parent.context)
////            .inflate(R.layout.item_sim_card, parent, false)
////        return SIMViewHolder(view)
////    }
////
////    override fun onBindViewHolder(holder: SIMViewHolder, position: Int) {
////        val item = getItem(position)
////        holder.bind(item, position == selectedPosition)
////        holder.itemView.setOnClickListener {
////            val previousPosition = selectedPosition
////            selectedPosition = holder.adapterPosition
////            notifyItemChanged(previousPosition)
////            notifyItemChanged(selectedPosition)
////            listener.onSIMClick(item)
////        }
////    }
////
////    class SIMViewHolder(view: View) : RecyclerView.ViewHolder(view) {
////        private val carrierName: TextView = view.findViewById(R.id.carrierNameTextView)
////        private val slotIndex: TextView = view.findViewById(R.id.slotIndexTextView)
////
////        fun bind(simData: SIMData, isSelected: Boolean) {
////            carrierName.text = "Carrier: ${simData.carrierName}"
////            slotIndex.text = "Slot: ${simData.slotIndex}, MCC: ${simData.mcc}, MNC: ${simData.mnc}"
////            itemView.setBackgroundColor(
////                if (isSelected) Color.LTGRAY else Color.WHITE
////            )
////        }
////    }
////
////    interface OnSIMClickListener {
////        fun onSIMClick(simData: SIMData)
////    }
////
////    companion object DiffCallback : DiffUtil.ItemCallback<SIMData>() {
////        override fun areItemsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
////            return oldItem.slotIndex == newItem.slotIndex
////        }
////
////        override fun areContentsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
////            return oldItem == newItem
////        }
////    }
////}
//
//
//
//
//
//
//class SIMListAdapter(private val listener: OnSIMClickListener) :
//    RecyclerView.Adapter<SIMListAdapter.SIMViewHolder>() {
//
//    private var simList = mutableListOf<SIMData>()
//
//    interface OnSIMClickListener {
//        fun onSIMClick(simData: SIMData)
//    }
//
//    fun submitList(list: List<SIMData>) {
//        simList.clear()
//        simList.addAll(list)
//        notifyDataSetChanged()
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SIMViewHolder {
//        val view = LayoutInflater.from(parent.context)
//            .inflate(R.layout.sim_list_item, parent, false)
//        return SIMViewHolder(view)
//    }
//
//    override fun onBindViewHolder(holder: SIMViewHolder, position: Int) {
//        val simData = simList[position]
//        holder.bind(simData)
//
//        holder.itemView.setOnClickListener {
//            listener.onSIMClick(simData)
//        }
//
//        holder.itemView.setOnLongClickListener { view ->
//            showContextMenu(view, simData)
//            true
//        }
//    }
//
//    override fun getItemCount(): Int = simList.size
//
//    private fun showContextMenu(view: View, simData: SIMData) {
//        val popupMenu = android.widget.PopupMenu(view.context, view)
//        popupMenu.inflate(R.menu.context_menu)
//
//        popupMenu.setOnMenuItemClickListener { menuItem ->
//            when (menuItem.itemId) {
//                R.id.action_balance -> {
//                    executeUSSD(view, "*111#")
//                    true
//                }
//                R.id.action_internet -> {
//                    executeUSSD(view, "*112#")
//                    true
//                }
//                R.id.action_roaming -> {
//                    executeUSSD(view, "*113#")
//                    true
//                }
//                else -> false
//            }
//        }
//
//        popupMenu.show()
//    }
//
//    private fun executeUSSD(view: View, ussdCode: String) {
//        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$ussdCode"))
//        try {
//            view.context.startActivity(intent)
//        } catch (e: SecurityException) {
//            Toast.makeText(view.context, "Permission required for USSD", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    inner class SIMViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        private val simName: TextView = itemView.findViewById(R.id.simNameTextView)
//
//        fun bind(simData: SIMData) {
//            simName.text = "SIM ${simData.slotIndex}: ${simData.carrierName}"
//        }
//    }
//
//    companion object DiffCallback : DiffUtil.ItemCallback<SIMData>() {
//        override fun areItemsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
//            return oldItem.slotIndex == newItem.slotIndex
//        }
//
//        override fun areContentsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
//            return oldItem == newItem
//        }
//    }
//}





// заново
package com.example.individual_work1
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

// виведення інформації про сімкарти
/*
class SIMListAdapter :
    ListAdapter<SIMData, SIMListAdapter.SIMViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SIMViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_sim_card, parent, false)
        return SIMViewHolder(view)
    }

    override fun onBindViewHolder(holder: SIMViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    class SIMViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val carrierName: TextView = view.findViewById(R.id.carrierNameTextView)
        private val slotIndex: TextView = view.findViewById(R.id.slotIndexTextView)

        fun bind(simData: SIMData) {
            carrierName.text = "Carrier: ${simData.carrierName}"
            slotIndex.text = "Slot: ${simData.slotIndex}, MCC: ${simData.mcc}, MNC: ${simData.mnc}"
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<SIMData>() {
        override fun areItemsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
            return oldItem.slotIndex == newItem.slotIndex
        }

        override fun areContentsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
            return oldItem == newItem
        }
    }
}
*/



// SIMListAdapter.kt
class SIMListAdapter(private val listener: OnSIMClickListener) :
    ListAdapter<SIMData, SIMListAdapter.SIMViewHolder>(DiffCallback) {

    private var selectedPosition = RecyclerView.NO_POSITION

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SIMViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_sim_card, parent, false)
        return SIMViewHolder(view)
    }

    override fun onBindViewHolder(holder: SIMViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, position == selectedPosition)
        holder.itemView.setOnClickListener {
            val previousPosition = selectedPosition
            selectedPosition = holder.adapterPosition
            notifyItemChanged(previousPosition)
            notifyItemChanged(selectedPosition)
            listener.onSIMClick(item)
        }
    }

    class SIMViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val carrierName: TextView = view.findViewById(R.id.carrierNameTextView)
        private val slotIndex: TextView = view.findViewById(R.id.slotIndexTextView)

        fun bind(simData: SIMData, isSelected: Boolean) {
            carrierName.text = "Carrier: ${simData.carrierName}"
            slotIndex.text = "Slot: ${simData.slotIndex}, MCC: ${simData.mcc}, MNC: ${simData.mnc}"
            itemView.setBackgroundColor(
                if (isSelected) Color.LTGRAY else Color.WHITE
            )
        }
    }

    interface OnSIMClickListener {
        fun onSIMClick(simData: SIMData)
    }

    companion object DiffCallback : DiffUtil.ItemCallback<SIMData>() {
        override fun areItemsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
            return oldItem.slotIndex == newItem.slotIndex
        }

        override fun areContentsTheSame(oldItem: SIMData, newItem: SIMData): Boolean {
            return oldItem == newItem
        }
    }
}


