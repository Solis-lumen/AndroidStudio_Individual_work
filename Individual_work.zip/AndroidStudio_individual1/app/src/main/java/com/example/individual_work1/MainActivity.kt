

// заново
// без нічого, просто виведення інформації про сімкарти
/*
package com.example.individual_work1
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.individual_work1.R
import com.example.individual_work1.SIMData
import com.example.individual_work1.SIMListAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private val simListAdapter = SIMListAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.simListRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = simListAdapter

        requestPermissions()
    }

    private fun requestPermissions() {
        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                loadSIMInfo()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.READ_PHONE_STATE)
        } else {
            loadSIMInfo()
        }
    }

    private fun loadSIMInfo() {
        val subscriptionManager =
            getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
        val telephonyManager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager

        val activeSims = subscriptionManager.activeSubscriptionInfoList
        val simDataList = mutableListOf<SIMData>()

        if (activeSims != null) {
            for (sim in activeSims) {
                val mccMnc = telephonyManager.simOperator ?: "Unknown"
                val mcc = mccMnc.substring(0, 3)
                val mnc = mccMnc.substring(3)
                simDataList.add(
                    SIMData(
                        carrierName = sim.carrierName.toString(),
                        slotIndex = sim.simSlotIndex,
                        mcc = mcc,
                        mnc = mnc
                    )
                )
            }
        }

        simListAdapter.submitList(simDataList)
    }
}
*/



// 2 текстбокса
/*
package com.example.individual_work1

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity(), SIMListAdapter.OnSIMClickListener {

    private lateinit var recyclerView: RecyclerView
    private val simListAdapter = SIMListAdapter(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.simListRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = simListAdapter

        requestPermissions()
    }

    private fun requestPermissions() {
        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                loadSIMInfo()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.READ_PHONE_STATE)
        } else {
            loadSIMInfo()
        }
    }

    private fun loadSIMInfo() {
        val subscriptionManager =
            getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
        val telephonyManager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager

        val activeSims = subscriptionManager.activeSubscriptionInfoList
        val simDataList = mutableListOf<SIMData>()

        if (activeSims != null) {
            for (sim in activeSims) {
                val mccMnc = telephonyManager.simOperator ?: "Unknown"
                val mcc = mccMnc.substring(0, 3)
                val mnc = mccMnc.substring(3)
                simDataList.add(
                    SIMData(
                        carrierName = sim.carrierName.toString(),
                        slotIndex = sim.simSlotIndex,
                        mcc = mcc,
                        mnc = mnc
                    )
                )
            }
        }

        simListAdapter.submitList(simDataList)
    }

    override fun onSIMClick(simData: SIMData) {
        // Показати доступні команди
        val commands = resources.getStringArray(R.array.operator_commands)
        val command = commands.getOrNull(simData.slotIndex) ?: "No command available"
        Toast.makeText(this, "Command: $command", Toast.LENGTH_SHORT).show()

        // Відкрити звонилку
        val dialIntent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$command")
        }
        startActivity(dialIntent)
    }
}
*/



// 2 variant
package com.example.individual_work1

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private lateinit var simSelectorSpinner: Spinner
    private lateinit var callButton: Button
    private lateinit var mobileDataSwitch: Switch
    private var selectedSimSlotIndex: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        simSelectorSpinner = findViewById(R.id.simSelectorSpinner)
        callButton = findViewById(R.id.callButton)
        mobileDataSwitch = findViewById(R.id.mobileDataSwitch)

        requestPermissions()
        setupListeners()
    }

    private fun requestPermissions() {
        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                loadSIMInfo()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.READ_PHONE_STATE)
        } else {
            loadSIMInfo()
        }
    }

    private fun loadSIMInfo() {
        val subscriptionManager =
            getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager

        val activeSims = subscriptionManager.activeSubscriptionInfoList
        val simOptions = mutableListOf<String>()

        activeSims?.forEach { sim ->
            simOptions.add("SIM ${sim.simSlotIndex}: ${sim.carrierName}")
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, simOptions)
        simSelectorSpinner.adapter = adapter
        simSelectorSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                selectedSimSlotIndex = position
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupListeners() {
        // Відкриття "звонилки"
        callButton.setOnClickListener {
            val phoneNumber = "" // Приклад номера
            val dialIntent = Intent(Intent.ACTION_DIAL)
            dialIntent.data = Uri.parse("tel:$phoneNumber")
            startActivity(dialIntent)
        }

        // Увімкнення/вимкнення мобільного Інтернету
        mobileDataSwitch.setOnCheckedChangeListener { _, isChecked ->
            setMobileDataState(isChecked)
        }
    }

    private fun setMobileDataState(enabled: Boolean) {
        try {
            val intent = Intent(Settings.ACTION_DATA_ROAMING_SETTINGS)
            startActivity(intent)
            Toast.makeText(
                this,
                "Manually enable/disable mobile data for SIM $selectedSimSlotIndex",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to open settings", Toast.LENGTH_SHORT).show()
        }
    }
}
