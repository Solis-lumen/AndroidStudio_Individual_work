package com.example.individual_work1

data class SIMData(
    val carrierName: String,
    val slotIndex: Int,
    val mcc: String,
    val mnc: String
)